print("cześć")

counter = 0

local function start(object)
  print(scene.pool)
  print(scene.pool:root())
  print(ObjectVariants.NODE)
  print(scene.pool:get(scene.pool:root()))
  local root = scene.pool:get(scene.pool:root())
  root:setVariant(ObjectVariants.MODEL)
  local modelref = root:model()
  print(modelref)
  print(modelref:model())
  modelref:setModel("CesiumMn.m3d")
  print(modelref:animationIdx())
  modelref:setAnimationIdx(-2)
  modelref:setAnimationIdx(-1)
  print(modelref:animationTime())
  modelref:setAnimationTime(100)
  print(modelref:animationSpeed())
  modelref:setAnimationSpeed(110)
  root:setName("coś")
  print(scene.pool:get(objH:new(1, 0)))
  print("witam")
  for i = 1, 10 do
    print(i)
  end

  object:setSelf({ id = counter })
  counter = counter + 1
end

local function frame(object)
  -- print("hi " .. scene:name())
  -- print(object:name())
  -- print("object's variant is " .. object:variant())
  -- print("is it NODE ", (object:variant() == ObjectVariants.NODE))
  -- print(object:toHandle(1))
  -- for i = 1, object:numChildren() do
  --   print("child is ", scene.pool:nthChildOf(object, i))
  -- end
  local paramtype, param = object:nthParam(1)
  if (paramtype == ParamTypes.STRING and param == "gex") then
    if (object:model()) then
      for i = 1, object:model():numMaterials() do
        print("material is ", object:model():nthMaterial(i))
        local material = object:model():nthMaterial(i);
        local color = material:color();
        color:setX(1 - color:x())
        color = Vec4:new(1 - color:x(), 1 - color:y(), 1 - color:z(), 1);
        material:setColor(color)
        material:setTexture("cat.obj/Cat_diffuse.png")
        object:model():setNthMaterial(i, material)
      end
    end
  end
  -- print(scene.pool:get(object:toHandle(1)))
end

scene:register_class {
  name = "cześć",
  params = {
    { "activate name", ParamTypes.STRING },
    { "printer",       ParamTypes.STRING | ParamTypes.INT | ParamTypes.FLOAT },
    { "whatever",      ParamTypes.ANY },
  },

  on_attach = start,

  on_update = function()
    for i = 1, scene.display_data:width() do
      print(scene.display_data:nthCell(i))
    end
  end,

  on_detach = function(object)
    print(":(")
    object:setSelf(nil)
  end,

  on_frame = function(object)
    local paramtype, param = object:nthParam(1)
    if (paramtype == ParamTypes.STRING and param == "gex") then
    --   -- print("frame obj id: " .. object:self().id)
    --   -- print("param #3 is ", object:nthParam(3))
      frame(object)
    end
  end,
}
